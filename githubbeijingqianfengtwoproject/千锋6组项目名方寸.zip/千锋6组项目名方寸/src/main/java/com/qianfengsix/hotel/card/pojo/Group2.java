package com.qianfengsix.hotel.card.pojo;
//                .-~~~~~~~~~-._       _.-~~~~~~~~~-.
//            __.'              ~.   .~              `.__
//          .'//                  \./                  \\`.
//        .'//                     |                     \\`.
//      .'// .-~"""""""~~~~-._     |     _,-~~~~"""""""~-. \\`.
//    .'//.-"                 `-.  |  .-'                 "-.\\`.
//  .'//______.============-..   \ | /   ..-============.______\\`.
//.'______________________________\|/______________________________`.

/**
 * Create By
 * AdminJen
 * ON
 * 2018 - 12 - 07
 * 星期五 <-> 下午 11:05
 */
public class Group2 {
    private int id;
    private String group_name;
    private String  group_person;
    private String group_city1;
    private String group_city2;
    private String group_city3;
    private String group_city4;
    private String group_tag1;
    private String group_tag2;
    private String group_tag3;
    private String group_img;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getGroup_name() {
        return group_name;
    }

    public void setGroup_name(String group_name) {
        this.group_name = group_name;
    }

    public String getGroup_person() {
        return group_person;
    }

    public void setGroup_person(String group_person) {
        this.group_person = group_person;
    }

    public String getGroup_city1() {
        return group_city1;
    }

    public void setGroup_city1(String group_city1) {
        this.group_city1 = group_city1;
    }

    public String getGroup_city2() {
        return group_city2;
    }

    public void setGroup_city2(String group_city2) {
        this.group_city2 = group_city2;
    }

    public String getGroup_city3() {
        return group_city3;
    }

    public void setGroup_city3(String group_city3) {
        this.group_city3 = group_city3;
    }

    public String getGroup_city4() {
        return group_city4;
    }

    public void setGroup_city4(String group_city4) {
        this.group_city4 = group_city4;
    }

    public String getGroup_tag1() {
        return group_tag1;
    }

    public void setGroup_tag1(String group_tag1) {
        this.group_tag1 = group_tag1;
    }

    public String getGroup_tag2() {
        return group_tag2;
    }

    public void setGroup_tag2(String group_tag2) {
        this.group_tag2 = group_tag2;
    }

    public String getGroup_tag3() {
        return group_tag3;
    }

    public void setGroup_tag3(String group_tag3) {
        this.group_tag3 = group_tag3;
    }

    public String getGroup_img() {
        return group_img;
    }

    public void setGroup_img(String group_img) {
        this.group_img = group_img;
    }
}
