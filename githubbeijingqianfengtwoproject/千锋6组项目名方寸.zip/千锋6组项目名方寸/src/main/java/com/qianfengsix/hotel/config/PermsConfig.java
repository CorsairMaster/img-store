package com.qianfengsix.hotel.config;
//                .-~~~~~~~~~-._       _.-~~~~~~~~~-.
//            __.'              ~.   .~              `.__
//          .'//                  \./                  \\`.
//        .'//                     |                     \\`.
//      .'// .-~"""""""~~~~-._     |     _,-~~~~"""""""~-. \\`.
//    .'//.-"                 `-.  |  .-'                 "-.\\`.
//  .'//______.============-..   \ | /   ..-============.______\\`.
//.'______________________________\|/______________________________`.


import org.springframework.context.annotation.Configuration;

/**
 * Create By
 * AdminJen
 * ON
 * 2018 - 11 - 02
 * 星期五 <-> 上午 10:12
 */
@Configuration
public class PermsConfig {
//    @Autowired
//    private PermsService permsService;
//    @PostConstruct
//    public void init() throws Exception {
//        permsService.addAllPerms();
//    }
}
